
probe_value = {
    "value": True,
    "negative_zero": -0.0,
    "false": False,
    "true": True,
}

import json as _json, math as _math
def probe_norm(v):
    if v is None: return ['null']
    if isinstance(v, bool): return ['bool', v]
    if isinstance(v, str): return ['string', v]
    if isinstance(v, (int, float)):
        return ['number', '-zero' if _math.copysign(1, v) < 0 else '+zero'] if v == 0 else ['number', v]
    if isinstance(v, dict): return ['dict', [[k, probe_norm(v[k])] for k in sorted(v)]]
    if isinstance(v, (list, tuple)): return [type(v).__name__, [probe_norm(x) for x in v]]
    raise TypeError(type(v))
print(_json.dumps({'value': probe_norm(probe_value)}, ensure_ascii=True, allow_nan=False))
