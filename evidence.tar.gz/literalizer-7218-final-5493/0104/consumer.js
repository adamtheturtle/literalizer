
function normalize(value) {
    if (value === null) return ["null"];
    if (typeof value === "boolean") return ["bool", value];
    if (typeof value === "string") return ["string", value];
    if (typeof value === "number") {
        return ["number", value === 0 ? (Object.is(value, -0) ? "-zero" : "+zero") : value];
    }
    if (Array.isArray(value)) return ["array", value.map(normalize)];
    if (value instanceof Map) {
        return ["map", [...value.keys()].sort().map(key => [key, normalize(value.get(key))])];
    }
    if (Object.getPrototypeOf(value) === Object.prototype) {
        return ["object", Object.keys(value).sort().map(key => [key, normalize(value[key])])];
    }
    throw Error("unexpected value");
}

const calls = [];

function consume(argument) {
    const keys = ["arg0", "arg1"];
    if (arguments.length !== 1 || Object.keys(argument).length !== keys.length ||
        !keys.every(key => Object.hasOwn(argument, key))) {
        throw Error("unexpected argument keys");
    }
    calls.push(keys.map(key => normalize(argument[key])));
}

consume({ arg0: "row-65", arg1: false });
consume({ arg0: "row-26", arg1: false });
consume({ arg0: "row-38", arg1: true });
process.stdout.write(JSON.stringify({calls}));
