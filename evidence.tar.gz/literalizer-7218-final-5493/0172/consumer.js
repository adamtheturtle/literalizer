
function normalize(value) {
    if (value === null) return ["null"];
    if (typeof value === "boolean") return ["bool", value];
    if (typeof value === "string") return ["string", value];
    if (typeof value === "number") {
        return ["number", value === 0 ? (Object.is(value, -0) ? "-zero" : "+zero") : value];
    }
    if (Array.isArray(value)) return ["array", value.map(normalize)];
    if (value instanceof Map) {
        return ["map", [...value.keys()].sort().map(key => [key, normalize(value.get(key))])];
    }
    if (Object.getPrototypeOf(value) === Object.prototype) {
        return ["object", Object.keys(value).sort().map(key => [key, normalize(value[key])])];
    }
    throw Error("unexpected value");
}

const calls = [];

function consume(...values) {
    if (values.length !== 4) throw Error("unexpected argument count");
    calls.push(values.map(normalize));
}

consume(`row-61`, `\\\``, 0x3f2, []);
consume(`row-6`, false, 0.000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000544563080088476, true);
consume(`row-83`, -0x11, true, new Map([
  [`$-bZacac`, new Map([
    [`__proto__`, -0x26d4],
  ])],
  [`Z`, [
    false,
    -0.00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000002225073858507,
    `'\t`,
  ]],
  [`a`, null],
]));
process.stdout.write(JSON.stringify({calls}));
