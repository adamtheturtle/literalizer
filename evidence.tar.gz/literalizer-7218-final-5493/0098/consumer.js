
function normalize(value) {
    if (value === null) return ["null"];
    if (typeof value === "boolean") return ["bool", value];
    if (typeof value === "string") return ["string", value];
    if (typeof value === "number") {
        return ["number", value === 0 ? (Object.is(value, -0) ? "-zero" : "+zero") : value];
    }
    if (Array.isArray(value)) return ["array", value.map(normalize)];
    if (value instanceof Map) {
        return ["map", [...value.keys()].sort().map(key => [key, normalize(value.get(key))])];
    }
    if (Object.getPrototypeOf(value) === Object.prototype) {
        return ["object", Object.keys(value).sort().map(key => [key, normalize(value[key])])];
    }
    throw Error("unexpected value");
}

const calls = [];

function consume(argument) {
    const keys = ["arg0", "arg1", "arg2", "arg3"];
    if (arguments.length !== 1 || Object.keys(argument).length !== keys.length ||
        !keys.every(key => Object.hasOwn(argument, key))) {
        throw Error("unexpected argument keys");
    }
    calls.push(keys.map(key => normalize(argument[key])));
}

consume({ arg0: "row-85", arg1: "\\9\\$-0\r\r\n_b_", arg2: -1739, arg3: true });
consume({ arg0: "row-43", arg1: null, arg2: {}, arg3: "" });
consume({ arg0: "row-48", arg1: "Y\"$\nb${\"", arg2: {"Y-": true, ["__proto__"]: [-0.0], "_Y": -52420.509168559685}, arg3: [null, null] });
process.stdout.write(JSON.stringify({calls}));
