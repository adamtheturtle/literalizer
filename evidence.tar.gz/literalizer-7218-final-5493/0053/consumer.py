
import json
import math

def normalize(value):
    if value is None:
        return ["null"]
    if isinstance(value, bool):
        return ["bool", value]
    if isinstance(value, str):
        return ["string", value]
    if isinstance(value, (int, float)):
        if value == 0:
            return ["number", "-zero" if math.copysign(1, value) < 0 else "+zero"]
        return ["number", value]
    if isinstance(value, dict):
        return ["dict", [[key, normalize(value[key])] for key in sorted(value)]]
    if isinstance(value, (list, tuple)):
        return [type(value).__name__, [normalize(item) for item in value]]
    raise TypeError(type(value))

calls = []
def consume(*, arg0, arg1, arg2):
    calls.append([normalize(value) for value in (arg0, arg1, arg2)])

consume(arg0='row-11', arg1=None, arg2=True)
consume(arg0='row-67', arg1=-4.782462262683448e5, arg2=0x126)
consume(arg0='row-13', arg1=0x176, arg2=[])
consume(arg0='row-45', arg1=[
    None,
    8.96576446619581e5,
    False,
], arg2='中$\t{Z\n\'é\x00$9X')
print(json.dumps({"calls": calls}, allow_nan=False))
