
function normalize(value) {
    if (value === null) return ["null"];
    if (typeof value === "boolean") return ["bool", value];
    if (typeof value === "string") return ["string", value];
    if (typeof value === "number") {
        return ["number", value === 0 ? (Object.is(value, -0) ? "-zero" : "+zero") : value];
    }
    if (Array.isArray(value)) return ["array", value.map(normalize)];
    if (value instanceof Map) {
        return ["map", [...value.keys()].sort().map(key => [key, normalize(value.get(key))])];
    }
    if (Object.getPrototypeOf(value) === Object.prototype) {
        return ["object", Object.keys(value).sort().map(key => [key, normalize(value[key])])];
    }
    throw Error("unexpected value");
}

const calls = [];

function consume(...values) {
    if (values.length !== 3) throw Error("unexpected argument count");
    calls.push(values.map(normalize));
}

consume(`row-36`, -0.000000, 0.000000);
consume(`row-17`, null, -0.00000000000000000000000000000000000000000000000000000000000000015177021687597715);
consume(`row-3`, new Map([
  [`a$`, null],
]), null);
consume(`row-29`, `Z -🙂'}\\$\\\x00
9`, ``);
process.stdout.write(JSON.stringify({calls}));
