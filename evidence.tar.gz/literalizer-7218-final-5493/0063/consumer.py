
import json
import math

def normalize(value):
    if value is None:
        return ["null"]
    if isinstance(value, bool):
        return ["bool", value]
    if isinstance(value, str):
        return ["string", value]
    if isinstance(value, (int, float)):
        if value == 0:
            return ["number", "-zero" if math.copysign(1, value) < 0 else "+zero"]
        return ["number", value]
    if isinstance(value, dict):
        return ["dict", [[key, normalize(value[key])] for key in sorted(value)]]
    if isinstance(value, (list, tuple)):
        return [type(value).__name__, [normalize(item) for item in value]]
    raise TypeError(type(value))

calls = []
def consume(*, arg0, arg1):
    calls.append([normalize(value) for value in (arg0, arg1)])

consume(arg0='row-23', arg1='}\rX\'\\a')
consume(arg0='row-42', arg1=-0.0)
consume(arg0='row-91', arg1=-0.0)
consume(arg0='row-31', arg1=0x2)
print(json.dumps({"calls": calls}, allow_nan=False))
