
import json
import math

def normalize(value):
    if value is None:
        return ["null"]
    if isinstance(value, bool):
        return ["bool", value]
    if isinstance(value, str):
        return ["string", value]
    if isinstance(value, (int, float)):
        if value == 0:
            return ["number", "-zero" if math.copysign(1, value) < 0 else "+zero"]
        return ["number", value]
    if isinstance(value, dict):
        return ["dict", [[key, normalize(value[key])] for key in sorted(value)]]
    if isinstance(value, (list, tuple)):
        return [type(value).__name__, [normalize(item) for item in value]]
    raise TypeError(type(value))

calls = []
def consume(*, arg0, arg1, arg2, arg3):
    calls.append([normalize(value) for value in (arg0, arg1, arg2, arg3)])

consume(arg0="row-63", arg1=(), arg2=419352.2788553247, arg3={"${x}": 930521.863851387, "a$X_a$_": None, "z": None})
consume(arg0="row-23", arg1={}, arg2=False, arg3=False)
consume(arg0="row-93", arg1=-146982.90139442636, arg2="\ra中}_a$\\0\r0_", arg3={"": None, "z": 0.1, "-Y-": 0.0})
consume(arg0="row-49", arg1=1.0, arg2=True, arg3={"$": True, "constructor": False, "YaXac": -897982.3317220447})
print(json.dumps({"calls": calls}, allow_nan=False))
