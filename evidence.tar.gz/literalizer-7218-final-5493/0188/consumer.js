
function normalize(value) {
    if (value === null) return ["null"];
    if (typeof value === "boolean") return ["bool", value];
    if (typeof value === "string") return ["string", value];
    if (typeof value === "number") {
        return ["number", value === 0 ? (Object.is(value, -0) ? "-zero" : "+zero") : value];
    }
    if (Array.isArray(value)) return ["array", value.map(normalize)];
    if (value instanceof Map) {
        return ["map", [...value.keys()].sort().map(key => [key, normalize(value.get(key))])];
    }
    if (Object.getPrototypeOf(value) === Object.prototype) {
        return ["object", Object.keys(value).sort().map(key => [key, normalize(value[key])])];
    }
    throw Error("unexpected value");
}

const calls = [];

function consume(...values) {
    if (values.length !== 4) throw Error("unexpected argument count");
    calls.push(values.map(normalize));
}

consume(`row-43`, `🙂}Y`, -0x1703a, 0.000000);
consume(`row-39`, 0.100000, 0.0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001, 0x38a);
process.stdout.write(JSON.stringify({calls}));
