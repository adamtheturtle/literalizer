
function normalize(value) {
    if (value === null) return ["null"];
    if (typeof value === "boolean") return ["bool", value];
    if (typeof value === "string") return ["string", value];
    if (typeof value === "number") {
        return ["number", value === 0 ? (Object.is(value, -0) ? "-zero" : "+zero") : value];
    }
    if (Array.isArray(value)) return ["array", value.map(normalize)];
    if (value instanceof Map) {
        return ["map", [...value.keys()].sort().map(key => [key, normalize(value.get(key))])];
    }
    if (Object.getPrototypeOf(value) === Object.prototype) {
        return ["object", Object.keys(value).sort().map(key => [key, normalize(value[key])])];
    }
    throw Error("unexpected value");
}

const calls = [];

function consume(argument) {
    const keys = ["arg0", "arg1", "arg2"];
    if (arguments.length !== 1 || Object.keys(argument).length !== keys.length ||
        !keys.every(key => Object.hasOwn(argument, key))) {
        throw Error("unexpected argument keys");
    }
    calls.push(keys.map(key => normalize(argument[key])));
}

consume({ arg0: "row-3", arg1: null, arg2: {} });
consume({ arg0: "row-66", arg1: "ZéZ", arg2: 49272 });
consume({ arg0: "row-54", arg1: "\n9a\r{", arg2: -548 });
process.stdout.write(JSON.stringify({calls}));
