
function normalize(value) {
    if (value === null) return ["null"];
    if (typeof value === "boolean") return ["bool", value];
    if (typeof value === "string") return ["string", value];
    if (typeof value === "number") {
        return ["number", value === 0 ? (Object.is(value, -0) ? "-zero" : "+zero") : value];
    }
    if (Array.isArray(value)) return ["array", value.map(normalize)];
    if (value instanceof Map) {
        return ["map", [...value.keys()].sort().map(key => [key, normalize(value.get(key))])];
    }
    if (Object.getPrototypeOf(value) === Object.prototype) {
        return ["object", Object.keys(value).sort().map(key => [key, normalize(value[key])])];
    }
    throw Error("unexpected value");
}

const calls = [];

function consume(argument) {
    const keys = ["arg0", "arg1", "arg2", "arg3"];
    if (arguments.length !== 1 || Object.keys(argument).length !== keys.length ||
        !keys.every(key => Object.hasOwn(argument, key))) {
        throw Error("unexpected argument keys");
    }
    calls.push(keys.map(key => normalize(argument[key])));
}

consume({ arg0: "row-63", arg1: [], arg2: 419352.2788553247, arg3: {"${x}": 930521.863851387, "a$X_a$_": null, "z": null} });
consume({ arg0: "row-23", arg1: {}, arg2: false, arg3: false });
consume({ arg0: "row-93", arg1: -146982.90139442636, arg2: "\ra中}_a$\\0\r0_", arg3: {"": null, "-Y-": 0.0, "z": 0.1} });
consume({ arg0: "row-49", arg1: 1.0, arg2: true, arg3: {"$": true, "YaXac": -897982.3317220447, "constructor": false} });
process.stdout.write(JSON.stringify({calls}));
