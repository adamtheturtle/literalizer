
import json
import math

def normalize(value):
    if value is None:
        return ["null"]
    if isinstance(value, bool):
        return ["bool", value]
    if isinstance(value, str):
        return ["string", value]
    if isinstance(value, (int, float)):
        if value == 0:
            return ["number", "-zero" if math.copysign(1, value) < 0 else "+zero"]
        return ["number", value]
    if isinstance(value, dict):
        return ["dict", [[key, normalize(value[key])] for key in sorted(value)]]
    if isinstance(value, (list, tuple)):
        return [type(value).__name__, [normalize(item) for item in value]]
    raise TypeError(type(value))

calls = []
def consume(*, arg0, arg1, arg2, arg3):
    calls.append([normalize(value) for value in (arg0, arg1, arg2, arg3)])

consume(arg0='row-61', arg1='\\`', arg2=0x3f2, arg3=[])
consume(arg0='row-6', arg1=False, arg2=5.44563080088476e-100, arg3=True)
consume(arg0='row-83', arg1=-0x11, arg2=True, arg3={
    '$-bZacac': {
        '__proto__': -0x26d4,
    },
    'Z': [
        False,
        -2.225073858507e-311,
        '\'\t',
    ],
    'a': None,
})
print(json.dumps({"calls": calls}, allow_nan=False))
